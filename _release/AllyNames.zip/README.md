# Ally Names

Gives silly names to allies, such as Drones, Turrets, Beetle Guards, etc.

Mod comes with default lists of names, but everything is 100% customizable in the config!

## Screenshots

<img src="https://cdn.discordapp.com/attachments/896038839422947340/1086652260819419246/image.png">
<img src="https://cdn.discordapp.com/attachments/896038839422947340/1086652322039484476/Risk_of_Rain_2_aIrXY1DUlr.png">

<img src="https://cdn.discordapp.com/attachments/896038839422947340/1086652460820602940/image.png">
<img src="https://cdn.discordapp.com/attachments/896038839422947340/1086652067231309934/image.png">


## Credits

<details><summary>Orso - <em>Names, Programming</em></summary>

- <a href="https://twitter.com/Orsopidou">Twitter</a>

</details>

<details><summary>SaltyFinalBoss - <em>Original Idea, Names, Icon</em></summary>

- <a href="https://twitter.com/saltyfinalboss">Twitter</a>, <a href="https://www.patreon.com/saltyfinalboss/">Patreon</a> 

</details>

## Changelog

<details>
<summary>Click to expand patch notes:</summary>

- 1.0.3
  - Fixed mod crashing when a config entry had no category.
- 1.0.2
  - Removed default names for Empathy Cores.
  - Added new names for TC-280 and Empathy Cores.
- 1.0.1
  - Removed debug logs left in the release.
- 1.0.0 - Initial Release

</details>